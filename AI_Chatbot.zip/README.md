# AI Chatbot Web Application

## Project Overview
The AI Chatbot is a simple web-based application developed using HTML, CSS, Flask, and basic Machine Learning concepts.

## How to Run
1. Install Flask: `pip install flask`
2. Run the app: `python app.py`
3. Open browser: `http://127.0.0.1:5000`

## Project Structure
```
AI_Chatbot/
├── app.py
├── chatbot.py
├── responses.json
├── templates/
│   └── index.html
├── static/
│   └── style.css
└── README.md
```

## Author
Think Champ Internship - Python with Generative AI (May 2026)
