import json
import random

# Load responses from JSON file
with open("responses.json", "r") as file:
    responses = json.load(file)

def get_response(user_message):
    # Convert to lowercase for matching
    message = user_message.lower().strip()

    # Check if message matches any key
    for key in responses:
        if key in message:
            return responses[key]

    # Default response if no match found
    default_responses = [
        "I am not sure about that. Can you ask something else?",
        "Interesting question! I am still learning. Try asking about Python or AI!",
        "Sorry, I don't understand that. Try asking about Python, AI, or Machine Learning!"
    ]
    return random.choice(default_responses)
